package funcionario;

import javax.swing.JOptionPane;

public class Coordenador extends Funcionario{
        private double salario;
        private double comissao;
        
        public Coordenador(){
            super(0,null,0,0,0,0);
        } 
  
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
   public void inserirFuncionario() {
        
         nome = JOptionPane.showInputDialog("Nome");
         cpf = Long.parseLong(JOptionPane.showInputDialog("CPF"));
         rg = Long.parseLong(JOptionPane.showInputDialog("RG"));
         salario = Double.parseDouble(JOptionPane.showInputDialog("Salario"));
         
   }
   
     public void calcularComissao(double comissao){
       comissao = getSalario()*0.15;
       this.comissao = comissao;
   }
        
     public void calcularInss(double inss)  {
       if(getSalario()>=1000){
           inss = getSalario()*0.11;
           this.inss = inss;
       }
       else{
           inss = getSalario()*0.9;
           this.inss = inss;
       }  
   }
        
      public void calcularSalariofinal(double salariofinal){
       salariofinal=getSalario() - getInss() + getComissao();
       this.salariofinal=salariofinal;
   }
      
      public void mostrarDados() {
       
       System.out.println("Nome: "+super.getNome());
       System.out.println("Cpf: "+super.getCpf());
       System.out.println("Rg: "+super.getRg());
       System.out.println("Salario: "+getSalario());
       System.out.println("Comissão: "+getComissao());
       System.out.println("Inss: "+super.getInss());
       System.out.println("Salario final: "+super.getSalariofinal());
       
   }
      
}
