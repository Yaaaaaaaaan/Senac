package funcionario;

import javax.swing.JOptionPane;

public class Interface {
  public static void main(String args[]){
      double salario=0;
      double inss=0;
      double comissao=0;
      double salario_prof=0;
      double salariofinal=0;
      int bt;
      
        Coordenador C=new Coordenador();
        Professor P=new Professor();
      
      System.out.println("SISTEMA DE VERIFICAÇÃO");
      System.out.println("");
      System.out.println("↓ FAVOR, ESCOLHA DENTRE AS OPÇÕES ABAIXO,UMA. ↓");
      System.out.println("←--------------------------------------------→");
      
      System.out.println("→ 1 ← PARA COORDENADOR.");
      System.out.println("→ 2 ← PARA PROFESSOR.");
      
      System.out.println("←--------------------------------------------→");
      bt=Integer.parseInt(JOptionPane.showInputDialog(""));
      
      switch(bt){
          case 1:
              System.out.println("→ COORDENADOR ←");
              System.out.println("↓ INFORMAÇÕES ↓");
                 C.inserirFuncionario();
                 C.calcularComissao(comissao);
                 C.calcularInss(inss);
                 C.calcularSalariofinal(salariofinal);
                 C.mostrarDados();
                 System.out.println("←--------------------------------------------→");
                 break;
          case 2:
              System.out.println("→ PROFESSOR ←");
              System.out.println("↓ INFORMAÇÕES ↓");
              System.out.println("←--------------------------------------------→");
                P.inserirFuncionario();
                P.calcularSalario_prof(salario_prof);
                P.calcularInss( inss);
                P. calcularSalariofinal( salariofinal);
                P.mostrarDados();
              System.out.println("←--------------------------------------------→");
              break;
               default:
              System.out.println("ESCOLHA APENAS ENTRE → C ← PARA COORDENADOR E → P ← PARA PROFESSOR.");
      }
  }
}

