package funcionario;

import javax.swing.JOptionPane;

public class Professor extends Funcionario {
    
        private int quantidade_tempo;
        private double hora_aula;
        private double salario_prof;
    
    public Professor(){
         super(0,null,0,0,0,0);
    }

    public int getQuantidade_tempo() {
        return quantidade_tempo;
    }

    public void setQuantidade_tempo(int quantidade_tempo) {
        this.quantidade_tempo = quantidade_tempo;
    }

    public double getHora_aula() {
        return hora_aula;
    }

    public void setHora_aula(double hora_aula) {
        this.hora_aula = hora_aula;
    }

    public double getSalario_prof() {
        return salario_prof;
    }

    public void setSalario_prof(double salario_prof) {
        this.salario_prof = salario_prof;
    }
      public void inserirFuncionario() {
        
         nome = JOptionPane.showInputDialog("Nome");
         cpf = Long.parseLong(JOptionPane.showInputDialog("CPF"));
         rg = Long.parseLong(JOptionPane.showInputDialog("RG"));
         hora_aula = Double.parseDouble(JOptionPane.showInputDialog("Hora Aula"));
         quantidade_tempo = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de Tempo"));
         
   }
   
     public void calcularSalario_prof(double salario_prof) {
       salario_prof = quantidade_tempo*hora_aula;
       this.salario_prof=salario_prof;
   }
     
       public void calcularInss(double inss)  {
       if(getSalario_prof()>=1000){
           inss = getSalario_prof()*0.11;
           this.inss = inss;
       }
       else{
           inss = getSalario_prof()*0.9;
           this.inss = inss;
       }  
   }
     
     public void calcularSalariofinal(double salariofinal) {
       salariofinal=getSalario_prof() - getInss();
       this.salariofinal=salariofinal;
   }
     
   public void mostrarDados() {
       
       System.out.println("Nome: "+super.getNome());
       System.out.println("Cpf: "+super.getCpf());
       System.out.println("Rg: "+super.getRg());
       System.out.println("Hora Aula: "+getHora_aula());
       System.out.println("Quantidade de Tempo: "+getQuantidade_tempo());
       System.out.println("Inss: "+super.getInss());
       System.out.println("Salario Professor: "+getSalario_prof());
       System.out.println("Salario final: "+super.getSalariofinal());
       
   }
}



